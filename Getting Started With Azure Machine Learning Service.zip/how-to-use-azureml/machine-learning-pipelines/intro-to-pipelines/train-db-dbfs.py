# Copyright (c) Microsoft. All rights reserved.
# Licensed under the MIT license.

print("In train.py")
print("As a data scientist, this is where I use my training code.")
