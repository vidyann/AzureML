# Copyright (c) Microsoft. All rights reserved.
# Licensed under the MIT license.

print('####################################')
print('Hello World (without Azure ML SDK)!')
print('####################################')
