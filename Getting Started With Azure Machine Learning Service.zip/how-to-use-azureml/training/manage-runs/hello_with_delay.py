# Copyright (c) Microsoft. All rights reserved.
# Licensed under the MIT license.

import time

print("Wait for 10 seconds..")
time.sleep(10)
print("Done waiting")
